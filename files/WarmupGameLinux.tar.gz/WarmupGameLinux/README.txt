Use "g++ -o WarmupGame main.cpp -lalleg-4.2.2 -lalleg_unsharable" to compile
Replace "4.2.2" with any Allegro version (4.*.*) that you have installed.