//TODO: fix ReadTextFile on DOS?
function DoLogo(arg1,arg2){arg1=(arg1 | 0)+240;var var7=0x2b00f5;var var8=0xfd68b2;var var10=0xff00ff;var var6=0x7FFFD4;if(GetConfig({gfx:{color_depth:0}}).gfx.color_depth==8){var10=0;var6=1;var7=2;var8=3;var var32=Uint8Array.allocPlain(1024);var32[var10*4]=(0 >> 18)& 63;var32[var10*4+1]=(0 >> 10)& 63;var32[var10*4+2]=(0 >> 2)& 63;var32[var6*4]=(0x7FFFD4 >> 18)& 63;var32[var6*4+1]=(0x7FFFD4 >> 10)& 63;var32[var6*4+2]=(0x7FFFD4 >> 2)& 63;var32[var7*4]=(0x2b00f5 >> 18)& 63;var32[var7*4+1]=(0x2b00f5 >> 10)& 63;var32[var7*4+2]=(0x2b00f5 >> 2)& 63;var32[var8*4]=(0xfd68b2 >> 18)& 63;var32[var8*4+1]=(0xfd68b2 >> 10)& 63;var32[var8*4+2]=(0xfd68b2 >> 2)& 63;SetPalette(var32);}var var38=200.0;var var34=-70.0*0.0174533;var var30=screen.w*0.5;var var31=screen.h*0.5;var var19=Array(7);var var18=Array(7);var var17=Array(7);for(var var20=0;var20 < 7*7;var20++){var19[var20]=0;var18[var20]=0;var17[var20]=0;}function Func1(){var var20=0;var var36=0;var var49=0;var var37=0;for(;var20 < 7;var20++){var49=(var20-3)*28.0;var36=180.0 /(var38+var49*Math.sin(var34));var19[var20]=var31+var49*Math.cos(var34)*var36;}var37=180.0 /(var38-3*28.0*Math.sin(var34));for(var20=0;var20 < 3;var20++){var18[var20]=var30+(var20-3)*28.0*var37;var17[var20]=var30+(var20-3)*28.0*var36;var18[4+var20]=var30-(var20-3)*28.0*var37;var17[4+var20]=var30-(var20-3)*28.0*var36;}var18[3]=var17[3]=var30;}function Func2(){var var20=0;var var46=var18[0];var var47=var18[4];var var48=var17[0]-var46;var var51=var19[0];var var50=1 /(var19[6]-var51);var var13=0;for(;var20 < 7;var20++){var13=var48*(var19[var20]-var51)*var50;HLine(screen,var46+var13,var19[var20],var47-var13,var6);Line(screen,var18[var20],var19[0],var17[var20],var19[7-1],var6);}}var var41=375.687;var var40=181.964;function Func4(){var var2=CreateBitmap(673,145);var var3=CreateBitmap(212,46);var var4=CreateBitmap(673,46);var var15=var7;ClearToColor(var3,var10);var var11=13;var var12=[   function(var45,var49,var47,y2,var5){var5=var5 ? var15 : var10;RectFill(var2,var45+var11,var49+var11,var47+var11,y2+var11,var5);return 5;},function(var45,var49,w,h,var5){var5=var5 ? var15 : var10;var45+=var11;var49+=var11;RectFill(var2,var45,var49,var45+w,var49+h,var5);return 5;},function(var46,y1,var47,y2,x3,y3,x4,y4,var5){var5=var5 ? var15 : var10;var46+=var11,y1+=var11,var47+=var11,y2+=var11,x3+=var11,y3+=var11,x4+=var11,y4+=var11;Triangle(var2,var46,y1,var47,y2,x3,y3,var5);Triangle(var2,var46,y1,x3,y3,x4,y4,var5);return 9;},function(var45,var49,w,h,var5){var5=var5 ? var15 : var10;var45+=var11;var49+=var11;EllipseFill(var2,var45+w*0.5,var49+h*0.5,w*0.5,h*0.5,var5);return 5;},function(var45,var49,r,var5){var45+=var11;var49+=var11;var5=var5 ? var15 : var10;CircleFill(var2,var45,var49,r,var5);return 4;}];var var9=[   0,12,4,27,126,1,2,28,60,82,4,105,4,28,85,1,2,46,61,57,52,116,126,98,126,1,3,127,4,104,124,1,3,127,17,88,96,0,1,143,16,30,97,0,1,127,5,50,13,1,1,127,113,46,13,1,0,127,4,143,126,1,0,254,4,269,126,1,3,276,4,77,70,1,4,318,39,20,0,1,270,17,47,40,0,1,270,4,51,14,1,1,270,58,51,14,1,2,299,71,319,71,335,84,317,84,1,2,335,84,317,84,344,126,362,126,1,0,380,4,395,126,1,0,460,4,475,126,1,2,395,4,395,25,460,126,460,104,1,0,507,4,523,126,1,3,547,0,110,108,1,3,550,14,113,115,1,3,565,14,77,90,0,3,567,29,76,87,0,2,673,89,669,38,583,46,587,74,0,0,0,0,0,0,0,0  ];var var20=0;var var45,var49,nextY;while(var15){ClearToColor(var2,var10);for(var20=0;var20 < var9.length;)var20+=1+var12[var9[var20]](var9[var20+1],var9[var20+2],var9[var20+3],var9[var20+4],var9[var20+5],var9[var20+6],var9[var20+7],var9[var20+8],var9[var20+9],var9[var20+10]);for(var45=13,var49=0;var49 < 145;var49=nextY){nextY=var49+124 / 26;Blit(var2,var4,0,Math.floor(var49),0,0,673,10);RectFill(var2,0,Math.floor(var49),673,Math.floor(nextY)-1,var10);Blit(var4,var2,0,0,var45,Math.floor(var49),673,Math.floor(nextY)-Math.floor(var49));var45--;}StretchBlit(var2,var4,0,0,var2.w,var2.h,0,0,var3.w,var3.h);MaskedBlit(var4,var3,0,0,0,0,var3.w,var3.h);var15=var15==var7 ? var8 : 0;var11=0;}return var3;}kdrnic=Func4();var var25=Math.max(screen.w,kdrnic.w)*3;var var24=(screen.w-kdrnic.w)*0.5;var var23=(screen.w-kdrnic.w)*0.5;var var14=[0,0.0017505657578546583,0.0036711906182773633,0.005765256126921048,0.008036121004137692,0.010487107909752933,0.013121488837261483,0.01594246907783131,0.01895316970486474,0.022156608543387666,0.025555679605604214,0.029153130994918904,0.03295154130590043,0.03695329457727138,0.04116055388917988,0.045575233734716065,0.05019897133866705,0.0550330971434136,0.060078604731946414,0.06533612051019959,0.07080587352390412,0.07648766583726148,0.08238084394987731,0.08848427177224616,0.09479630571604326,0.10131477248083716,0.10803695013084032,0.11495955305137204,0.12207872135256463,0.1293900152457908,0.136888414855361,0.14456832584420728,0.15242359112857878,0.160447508835437,0.16863285652063645,0.17697192152058078,0.1854565371602214,0.19407812439203737,0.20282773830028086,0.21169611877850186,0.22067374458182937,0.22975088987347703,0.23891768233096478,0.24816416185369852,0.2574803389202754,0.266856251680084,0.2762820209268539,0.2857479021879675,0.29524433426782254,0.30476198370101515,0.31429178469607527,0.32382497427753243,0.33335312245829946,0.34286815739144244,0.35236238555693433,0.3618285071324357,0.37125962677589136,0.3806492601110362,0.3899913362547883,0.3992801967586075,0.4085105913553958,0.41767767091086583,0.42677697797524805,0.43580443531952184,0.4447563328218384,0.45362931304614795,0.46242035582781615,0.47112676215158306,0.4797461375767729,0.4882763754341635,0.4967156399891718,0.5050623497375784,0.5133151609733585,0.5214729517435673,0.5295348062828446,0.5375,0.545367985071337,0.553138376679762,0.5608109399252527,0.5683855774207246,0.5758623175776229,0.5832413035774908,0.5905227830191546,0.5977070982258571,0.6047946771925081,0.6117860251500356,0.6186817167214972,0.6254823886430093,0.6321887330215455,0.6388014911011769,0.6453214475092404,0.6517494249542,0.6580862793474798,0.6643328953223074,0.6704901821234942,0.6765590698431162,0.6825405059781395,0.6884354522872154,0.6942448819250298,0.6999697768338023,0.7056111253727028,0.7111699201671243,0.7166471561608839,0.7220438288555256,0.7273609327219455,0.7325994597705797,0.7377603982673534,0.7428447315834915,0.7478534371681693,0.7527874856337753,0.7576478399443315,0.7624354546983232,0.7671512754978617,0.7717962383967251,0.7763712694204009,0.7808772841517964,0.7853151873767792,0.7896858727841877,0.7939902227153635,0.7982291079586745,0.802403387584857,0.8065139088193495,0.8105615069481037,0.8145470052536524,0.8184712149784802,0.8223349353129874,0.8261389534055725,0.8298840443925596,0.8335709714458972,0.8372004858367266,0.8407733270130865,0.8442902226901667,0.847751888951664,0.8511590303609168,0.8545123400806176,0.8578125000000001,0.8610601808685058,0.8642560424350175,0.8674007335918309,0.8704948925226155,0.8735391468536807,0.8765341138079265,0.8794804003609227,0.8823786033986027,0.8852293098761203,0.8880330969774521,0.8907905322753727,0.8935021738914691,0.8961685706558932,0.8987902622665822,0.9013677794477065,0.9039016441071308,0.9063923694926973,0.9088404603471615,0.9112464130616339,0.9136107158273947,0.9159338487859666,0.9182162841773505,0.9204584864863342,0.9226609125868048,0.9248240118839989,0.9269482264546454,0.9290339911849532,0.9310817339064141,0.9330918755293925,0.9350648301744873,0.937001005301646,0.938900801837032,0.9407646142976397,0.942592830913658,0.9443858337485936,0.9461439988171603,0.9478676962009494,0.9495572901619016,0.9512131392535907,0.9528355964303517,0.9544250091542653,0.9559817195000339,0.957506064257768,0.9589983750337183,0.960458978348974,0.9618881957361655,0.9632863438341963,0.9646537344810393,0.9659906748046291,0.9672974673118778,0.968574409975855,0.9698217963211584,0.9710399155075098,0.9722290524116131,0.9733894877072984,0.9745214979439963,0.9756253556235667,0.9767013292755161,0.9777496835306406,0.9787706791931208,0.9797645733111008,0.9807316192457872,0.9816720667390944,0.9825861619798686,0.983474147668719,0.9843362630814905,0.9851727441313994,0.9859838234298683,0.9867697303460851,0.9875306910653127,0.9882669286459781,0.9889786630755716,0.9896661113253716,0.990329487404036,0.990969002410069,0.9915848645832044,0.9921772793547146,0.9927464493966821,0.9932925746702468,0.9938158524728591,0.9943164774845564,0.9947946418132875,0.9952505350393057,0.9956843442586508,0.9960962541257425,0.9964864468951016,0.9968551024622238,0.9972023984036186,0.9975285100160409,0.9978336103549231,0.9981178702720346,0.9983814584523814,0.9986245414503633,0.9988472837252075,0.9990498476756933,0.9992323936741828,0.9993950800999748,0.9995380633719987,0.9996614979808578,0.9997655365202426,0.9998503297177247,0.9999160264649445,0.9999627738472106,0.999990717172517];var var16=0;var var29=Loop;var var26=new Uint8Array(3);var var27=var26.subarray(0,2);var var28=var26;function Func3(){var var21=var14[Math.min(var16,var14.length-1)];var38=var41+(var40-var41)*var21;var34=-70*0.0174533*var21;var var22=var25+(var24-var25)*var21;Func1();ClearToColor(screen,0);Func2();DrawBitmap(screen,kdrnic,var22,var23);var28[0]=0xB0;var28[1]=0x07;var28[2]=Math.max(0,127-Math.max(0,var16-100)*(127 /(240-100)));MIDIOut(var28);var16++;if(var16 >=arg1){var28.set([0x90,0x3C,0]);MIDIOut(var28);var28.set([0x90,0x3C+4,0]);MIDIOut(var28);var28.set([0x90,0x3C+7,0]);MIDIOut(var28);Loop=var29;if(arg2)arg2();}}Loop=Func3;var28.set([0xB0,0x07,127]);MIDIOut(var28);var27.set([0xC0,89]);MIDIOut(var27);var28.set([0x90,0x3C,127]);MIDIOut(var28);var28.set([0x90,0x3C+4,127]);MIDIOut(var28);var28.set([0x90,0x3C+7,127]);MIDIOut(var28);}

var highscore = GetConfig({gamedata:{highscore: 0}}).gamedata.highscore;
var song = LoadMIDI("song.mid");
var gfx = LoadBitmap("gfx.pcx");
var pal = LastBitmapPalette();
pal[0] = 0;
pal[1] = 0;
pal[2] = 0;
pal[3] = 0;

//TODO: fix CreateSubBitmap on DOS?
function _CreateSubBitmap(bmp, x, y, w, h)
{
	var sub = CreateBitmap(w, h);
	ClearToColor(sub, 0);
	Blit(bmp, sub, x, y, 0, 0, w, h);
	return sub;
}

var runGc = false;
var sprPoo =		_CreateSubBitmap(gfx, 9, 2, 32, 30);
var sprConker =		_CreateSubBitmap(gfx, 41, 1, 40, 45);
var sprGameOver =	_CreateSubBitmap(gfx, 3, 57, 317, 44);
var sprCash =		_CreateSubBitmap(gfx, 1, 31, 40, 22);
gfx = null;

function RunGc()
{
	Duktape.gc();
	Loop = LoopReal;
	ClearToColor(screen, 12);
	SetPalette(pal);
	PlayMIDI(song, true);
	gameOver = false;
	conkerX = (screen.w - sprConker.w) * 0.5;
	conkerY = (screen.h - sprConker.h) * 0.5;
	poops = [{}];
	frame = 0;
	SpawnPoop(poops[poops.length - 1]);
	cash = {x: 0, y: 0};
	cashAlive = false;
	score = 0;
}

var i;
var temp;

function SpawnPoop(p)
{
	p.x = screen.w * 0.5;
	p.y = screen.h * 0.5;
	var angle = Math.random() * 6.283;
	p.dx = Math.cos(angle) * 2;
	p.dy = Math.sin(angle) * 2;
	p.x -= p.dx * 350;
	p.y -= p.dy * 350;
	p.x += (Math.random() - 0.5) * 100;
	p.y += (Math.random() - 0.5) * 100;
}

var radius2 = 20;
function ConkerColl(){
	var ax = conkerX + 30;
	var ay = conkerY + 30;
	var bx = temp.x + 20;
	var by = temp.y + 20;
	return (Math.abs(ax - bx) < (radius2) && Math.abs(ay - by) < (radius2));
}

SetTextBgColor(-1);
function LoopReal()
{
	ClearToColor(screen, 12);
	DrawBitmap(screen, sprConker, conkerX, conkerY);
	if(cashAlive) DrawBitmap(screen, sprCash, cash.x, cash.y);
	TextOut(screen, "SCORE: $" + score + " HI: $" + highscore, 0, 0, 80);
	
	if(gameOver){
		if(score > highscore){
			highscore = score;
			SetConfig({gamedata:{highscore:highscore}});
		}
		DrawBitmap(screen, sprGameOver, (screen.w - sprGameOver.w) * 0.5, (screen.h - sprGameOver.h) * 0.5);
		if(buttons[0] & BUTTON_START){
			Loop = RunGc;
		}
	}
	else{
		conkerX += dpad[0].x * 3;
		conkerY += dpad[0].y * 3;
		
		if(cashAlive){
			temp = cash;
			if(ConkerColl()){
				score += 100;
				cashAlive = false;
			}
		}
		
		for(i = 0; i < poops.length; i++){
			temp = poops[i];
			temp.x += temp.dx;
			temp.y += temp.dy;
			
			if(ConkerColl()){
				gameOver = true;
			}
			
			if(temp.x < -100 && temp.dx < 0) SpawnPoop(temp);
			else if(temp.x > 420 && temp.dx > 0) SpawnPoop(temp);
			else if(temp.y < -100 && temp.dy < 0) SpawnPoop(temp);
			else if(temp.y > 300 && temp.dy > 0) SpawnPoop(temp);
			
			DrawBitmap(screen, sprPoo, temp.x, temp.y);
		}
		frame++;
		if(frame % 120 == 0){
			poops.push({});
			SpawnPoop(poops[poops.length - 1]);
		}
		if((frame % 30 == 0) && !cashAlive){
			cashAlive = true;
			cash.x = Math.random() * 310;
			cash.y = Math.random() * 180;
		}
	}
}

Loop = RunGc;
DoLogo();