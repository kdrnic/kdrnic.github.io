cd dosbox074
nohup dosbox.exe -conf tapegro.conf -noconsole &