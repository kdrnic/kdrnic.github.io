start ..\..\Utilities\dosbox-x.exe -conf dosbox.conf 
