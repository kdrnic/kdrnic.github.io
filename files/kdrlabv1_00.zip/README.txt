        ,----,                                            
      ,/   .`|              ,----..                       
    ,`   .'  :,-.----.     /   /   \    ,----..           
  ;    ;     /\    /  \   /   .     :  /   /   \          
.'___,/    ,' ;   :    \ .   /   ;.  \|   :     :         
|    :     |  |   | .\ :.   ;   /  ` ;.   |  ;. /         
;    |.';  ;  .   : |: |;   |  ; \ ; |.   ; /--`          
`----'  |  |  |   |  \ :|   :  | ; | ';   | ;  __         
    '   :  ;  |   : .  /.   |  ' ' ' :|   : |.' .'        
    |   |  '  ;   | |  \'   ;  \; /  |.   | '_.' :        
    '   :  |  |   | ;\  \\   \  ',  / '   ; : \  |        
    ;   |.'   :   ' | \.' ;   :    /  '   | '/  .'        
    '---'     :   : :-'    \   \ .'   |   :    /          
              |   |.'       `---`      \   \ .'           
              `---'            .--,-``-.`---`             
                              /   /     '.      ,---,     
                             / ../        ;   .'  .' `\   
                             \ ``\  .`-    ',---.'     \  
                              \___\/   \   :|   |  .`\  | 
                                   \   :   |:   : |  '  | 
                                   /  /   / |   ' '  ;  : 
                                   \  \   \ '   | ;  .  | 
                               ___ /   :   ||   | :  |  ' 
                              /   /\   /   :'   : | /  ;  
                             / ,,/  ',-    .|   | '` ,/   
                             \ ''\        ; ;   :  .'     
                              \   \     .'  |   ,.'       
                               `--`-,,-'    '---'         
             _       _            _      _                  
            | |     | |          (_)    ( )                 
            | | ____| |_ __ _ __  _  ___|/ ___              
            | |/ / _` | '__| '_ \| |/ __| / __|             
            |   < (_| | |  | | | | | (__  \__ \             
            |_|\_\__,_|_|_ |_| |_|_|\___| |___/   _   _     
                | |     | |              (_)     | | | |    
                | | __ _| |__  _   _ _ __ _ _ __ | |_| |__  
                | |/ _` | '_ \| | | | '__| | '_ \| __| '_ \ 
                | | (_| | |_) | |_| | |  | | | | | |_| | | |
                |_|\__,_|_.__/ \__, |_|  |_|_| |_|\__|_| |_|
                                __/ |                       
                               |___/                        
							              v1.00 (2026/10/17)
										  
"TROG 3D : kdrnic's labyrinth" is a game for MS-DOS and MS-Windows 95 and 
above.
It is a First-Person Shooter in a vague fantasy setting.
It uses "raycaster" method of 3D rendering, like Wolfeinstein-3D by id
software.
It has over one hour of gameplay: I took ~55 minutes to complete all 12 levels,
knowing the game very well.
It has 12 main levels.
It was developed between January 2021 and finished in 2026.

SYSTEM REQUIREMENTS
===============================================================================
CPU: 486 or above. Although a Pentium 60 is much more comfortable.
RAM: 8+MB
Sound card: Sound Blaster 16 or compatible.

DEFAULT KEY BINDINGS
===============================================================================
Left Ctrl          Fire weapon
KEY_LSHIFT         Hold to run
Number row E       Select next Weapon
Number row Q       Select previous Weapon
Number row 1       Weapon1 - Knife or Fist
Number row 2       Weapon2 - Pistol
Number row 3       Weapon3 - Shotgun
Number row 4       Weapon4 - Machine gun
Number row 5       Weapon5 - Orb gun
Number row 6       Weapon6 - Rocket launcher
A                  Strafe left
D                  Strafe right
Left               Turn left
Right              Turn right
W                  Move forward
S                  Retreat
Alt                Hold to strafe
M                  Map
R                  Reload weapon (rarely required)
Function key F5    Start recording a GIF video
Function key F6    Stop recording a GIF video
Function key F4    Save state (hacky, unsafe)
Function key F8    Load save (hacky, unsafe)

CHEAT CODES
===============================================================================
Just type any of those at any point during gameplay.

KDRBEHOLDA            Uncovers the whole map (press M key)
KDRFA                 All weapons, full ammo and full armor
KDRKFA                All weapons, full ammo, full armor, and all keys
KDRSPISPOPD           Walk through walls (noclip)
KDRDQD                Turns on god mode
KDRPOX                Kill all enemies
KDRMPOX               Kill all enemies except skeletons
KDRXRAY               X-ray vision (3 modes, enter code repeatedly)
KDRTELEK1             Teleport to key 1
KDRTELEK2             Teleport to key 1
KDRTELEK3             Teleport to key 1
KDRTELEL1             Teleport to lock 1
KDRTELEL2             Teleport to lock 1
KDRTELEL3             Teleport to lock 1
KDRTELEXT             Teleport to level exit
KDRWOLF               Turns all enemies into Wolfeinstein 3D guards
KDRBUNY               Turns all enemies into bunnies
KDRBEHOLDC            Give player a CLOCK (temporarily stops time)
KDRLVLRST             Reset level records for current level
KDRDMG                Game Boy (Dot Matrix Game) mode 
KDRCRANKUP            Fast firing rate for current weapon

DEMO FILES
===============================================================================
The game automatically records "demonstration" (demo) files to directory 
./demos/

Those are like a video but store only player inputs, thus low file size.
They are easily shared.

Those have the following file name format:
MMDDHHmm.REC     Month, Day, Hour, minute

They are also copied to the following other file names:
xxxxx.1ST        First successful completion of level xxxxx
xxxxx.BKI        Best kills for level xxxxx
xxxxx.BTI        Best time for level xxxxx
xxxxx.BHO        Most skeleton golf holes for level xxxxx

F.A.Q. (Florian-Asked Questions)
===============================================================================
Q: Could the game have better performance? A raycaster can run on a 286.
A: Yes, but I chose not to use Assembly or other extreme optimizations.

Q: Why does it require a floating point unit?
A: Neither the game logic nor the renderer use floating point operations 
(all fixed point), but some initialization stuff uses floating point. I can't
be arsed to fix this.

Q: Isn't the executable quite large?
A: Yes, due to use of Allegro 4, even an "empty" Allegro 4 program is almost 
1MB.

Q: Could it be made to not use Allegro 4 at all?
A: Yes, in fact the main rendering routines use no Allegro 4 at all. But, I
can't be arsed to write all the low-level code.

Q: Isn't RAM usage quite high?
A: Yes, in part due to the huge executable.

Q: It has MIDI setup but no music, what happened?
A: I didn't bother to include any music since the game lacked interest.

Q: Is this a true MS-DOS game?
A: No, I don't have a DOS era computer, have never had, and no real nostalgia 
for it. But it runs in DOSBox.

Q: Can it truly run in Windows 95?
A: It was tested in a VM. But it is a bit tricky to have it run right. 
Windows 98 or Windows XP is more guaranteed.
It runs well in Windows 8/10/11 also.

CONTACT INFORMATION
===============================================================================
Mastodon          https://dosgame.club/@kdrnic
IRC               #dosgameclub @ irc.afternet.org
Website           https://kdrnic.github.io/

CREDITS
===============================================================================
PROGRAMMING by                              
    kdrnic                                  
                                            
ORIGINAL 2D ART by                          
    kdrnic                                  
    VanderSalva                             
                                            
Sound effect edits by                       
    kdrnic                                  
                                            
Game inspired by/made for                   
    9th kajam game jam                      
    (https://alakajam.com/9th-kajam)        
    by toasty                               
                                            
Allegro 4 game library                      
    by Shawn Hargreaves et al               
                                            
Initial\old raycaster code                  
    by Lode Vandevenne                      
                                            
The Best IRC Channel                        
    #dosgameclub @ irc.afternet.org         
with special thanks to                      
    rnlf voxel patrick_wd                   
                                            
Open Game Art (opengameart.org) SFX         
--------------------------------------------
RPG Sound Pack                              
                             by artisticdude
Chaingun, pistol, rifle, shotgun shots      
                                  by qubodup
25 CC0 bang / firework SFX                  
                               by rubberduck
Cork                                        
                                   by Lamoot
Bubble Pop                                  
                                 by pokmon63
Evil Laugh                                  
                              by AntumDeluge
50 CC0 Sci-Fi SFX                           
                               by rubberduck
Action Shooter Soundset (WWVi)              
                                  by qubodup
Fantasy Weapons and Apparel SFX Library     
                                  by Vehicle
Synthesized Fire Sound Effect               
 by Spring Spring                           
Female RPG Voice Starter Pack               
                                 by cicifyre
202 More Sound Effects                      
                              by OwlishMedia
5 break, crunch impacts                     
                                  by qubodup
80 CC0 creature SFX                         
                               by rubberduck
512 Sound Effects (8-bit style)             
                            by SubspaceAudio
Archers shooting                            
                                  by copyc4t
Squeaky Rat                                 
                                  by qubodup
Aargh! (male screams)                       
                             by congusbongus
3 dark magic spells                         
                                  by qubodup
Water Splash and sand footsteps             
                                   by Peludo
Ticking clock.                              
                                     by bart
Bowling Ball Rolling                        
                                  by qubodup
Scrapes                                     
                              by AntumDeluge
Punch, slap, n' kick                        
                             by congusbongus
Stop                                        
                                   by Lamoot
various scissors                            
                                    by sinny
Helicopter Sounds                           
                                   by aquinn
Open Game Art (opengameart.org) 2D art      
--------------------------------------------
Sign Pack                                   
                                    by Nikke
Stunning Pixel Art RPG Tileset              
                              by uheartbeast
Misc. Dark Fantasy Scenery Sprites          
                             by ETTiNGRiNDER
Classical Ruin Tiles                        
                                     by surt
Basic map 32x32 by Ivan voirol              
 by Ivan Voirol                             
32x32 (and 16x16) RPG Tiles--Forest and some
Interior Tiles                              
                                by Redshrike
Firearm weapons                             
 by fmunoz.geo                              
Some Modified Assets from Fantasy Icon       
Pack by Ravenmore                           
                                     by mold
Fantasy Icon Pack by Ravenmore              
                                by Ravenmore
CC0 Hand Wear Icons                         
                              by AntumDeluge
UndeadEmpire tileset (64x64) repack (floor, 
lava, walls and effects)                    
 by lukems-br                               
Grunge Tileset                              
                                   by mfburn
Various inventory 24 pixel icon set         
                                  by qubodup
[LPC] Birds                                 
                             by bluecarrot16
Haunted Forest Trees                        
                             by ETTiNGRiNDER
Old Wooden Props 32x32                      
                              by ImogiaGames
Game wood panel                             
                               by PINKCANNON
Splash Effect [32x32]                       
 by Jesse McCarthy                          
Bunny Rabbit LPC style for PixelFarm        
                                by Redshrike
[LPC] Blacksmith                            
                             by bluecarrot16
Flying Broom (Witchcraft)                   
                                    by Xacur
Shovel                                      
                              by AntumDeluge
High res fire ball                          
 by Game Developer Studio                   
Crocodile trap                              
                                 by knik1985
Primitive Village                           
                                by Vomdrache
Open Game Art (opengameart.org) 3D art      
--------------------------------------------
FLARE Mod - Hobgoblin Archer                
                                 by VWolfdog

Open Game Art links
===============================================================================
https://opengameart.org/content/rpg-sound-pack
https://opengameart.org/content/chaingun-pistol-rifle-shotgun-shots
https://opengameart.org/content/25-cc0-bang-firework-sfx
https://opengameart.org/content/cork
https://opengameart.org/content/bubble-pop
https://opengameart.org/node/81237
https://opengameart.org/content/50-cc0-sci-fi-sfx
https://opengameart.org/content/action-shooter-soundset-wwvi
https://opengameart.org/content/fantasy-weapons-and-apparel-sfx-library
https://opengameart.org/content/synthesized-fire-sound-effect
https://opengameart.org/content/female-rpg-voice-starter-pack
https://opengameart.org/content/202-more-sound-effects
https://opengameart.org/content/5-break-crunch-impacts
https://opengameart.org/content/80-cc0-creature-sfx
https://opengameart.org/content/512-sound-effects-8-bit-style
https://opengameart.org/content/archers-shooting
https://opengameart.org/content/squeaky-rat
https://opengameart.org/content/aargh-male-screams
https://opengameart.org/content/3-dark-magic-spells
https://opengameart.org/content/water-splash-and-sand-footsteps
https://opengameart.org/content/ticking-clock
https://opengameart.org/content/bowling-ball-rolling
https://opengameart.org/content/scrapes
https://opengameart.org/content/punch-slap-n-kick
https://opengameart.org/content/stop
https://opengameart.org/content/various-scissors
https://opengameart.org/content/helicopter-sounds
https://opengameart.org/content/pixel-art-portal-sprites
https://opengameart.org/content/sign-pack
https://opengameart.org/content/stunning-pixel-art-rpg-tileset
https://opengameart.org/content/misc-dark-fantasy-scenery-sprites
https://opengameart.org/content/classical-ruin-tiles
https://opengameart.org/content/basic-map-32x32-by-ivan-voirol
https://opengameart.org/content/32x32-and-16x16-rpg-tiles-forest-and-some-interior-tiles
https://opengameart.org/content/firearm-weapons
https://opengameart.org/content/some-modified-assets-from-fantasy-icon-pack-by-ravenmore
https://opengameart.org/content/fantasy-icon-pack-by-ravenmore-0
https://opengameart.org/content/cc0-hand-wear-icons
https://opengameart.org/content/undeadempire-tileset-64x64-repack-floor-lava-walls-and-effects
https://opengameart.org/content/grunge-tileset
https://opengameart.org/content/various-inventory-24-pixel-icon-set
https://opengameart.org/content/lpc-birds
https://opengameart.org/content/haunted-forest-trees
https://opengameart.org/content/old-wooden-props-32x32
https://opengameart.org/content/game-wood-panel
https://opengameart.org/content/splash-effect-32x32
https://opengameart.org/content/bunny-rabbit-lpc-style-for-pixelfarm
https://opengameart.org/content/lpc-blacksmith
https://opengameart.org/content/flying-broom-witchcraft
https://opengameart.org/content/shovel-1
https://opengameart.org/content/high-res-fire-ball
https://opengameart.org/content/crocodile-trap
https://opengameart.org/content/primitive-village
https://opengameart.org/content/flare-mod-hobgoblin-archer
https://opengameart.org/content/coat-of-arms-set
