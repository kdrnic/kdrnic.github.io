/*
 * kdrgbtags - tags file generator for RGBDS object files
 *
 * by kdrnic (kdrnic.github.io) May 2023
 * 
 * CHANGELOG
 * 2023/06/03 Increased statically allocated memory
 * 2023/05/20 First version
 * 
 * Copyright (c) 2023 kdrnic
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <assert.h>
#include <ctype.h>

// OBJ format specific type definitions ------------------------------------------

typedef int32_t rgbLONG_t;
typedef int8_t rgbBYTE_t;

#define RGBNODE_TYPE_REPT  0
#define RGBNODE_TYPE_FILE  1
#define RGBNODE_TYPE_MACRO 2
#define RGBNODE_TYPE_MAX   RGBNODE_TYPE_MACRO

struct rgbNode
{
	const char *name;
	rgbLONG_t
		parentID,
		parentLineNo,
		depth;
	rgbBYTE_t type;
};

#define RGBSYMBOL_TYPE_LOCAL  0
#define RGBSYMBOL_TYPE_IMPORT 1
#define RGBSYMBOL_TYPE_EXPORT 2
#define RGBSYMBOL_TYPE_MAX    RGBSYMBOL_TYPE_EXPORT

struct rgbSymbol
{
	const char
		*name;
	rgbLONG_t
		nodeID,
		lineNo,
		sectionId,
		value;
	rgbBYTE_t
		type;
};

#define RGBSECTION_TYPE_WRAM0 0
#define RGBSECTION_TYPE_VRAM  1
#define RGBSECTION_TYPE_ROMX  2
#define RGBSECTION_TYPE_ROM0  3
#define RGBSECTION_TYPE_HRAM  4
#define RGBSECTION_TYPE_WRAMX 5
#define RGBSECTION_TYPE_SRAM  6
#define RGBSECTION_TYPE_OAM   7
#define RGBSECTION_TYPE_MAX   RGBSECTION_TYPE_OAM

struct rgbSection
{
	const char
		*name;
	rgbLONG_t
		size,
		address,
		bank,
		alignOfs,
		numPatches;
	rgbBYTE_t
		type,
		alignment;
};

// Statically allocated obj data -------------------------------------------------

//The largest commercial GB "game" is the Bible cart I believe - at one megabyte - so this ought to be quite generous
#define ONE_MEGABYTE (1024*1024)
#define NUM_SYMBOLS_MAX  (ONE_MEGABYTE/16)
#define NUM_NODES_MAX    (ONE_MEGABYTE/16)
#define NUM_SECTIONS_MAX (ONE_MEGABYTE/16)
#define STRING_LEN_MAX   256
#define STRING_BUF_LEN   ONE_MEGABYTE

struct rgbSymbol symbols[NUM_SYMBOLS_MAX];
struct rgbNode nodes[NUM_NODES_MAX];
struct rgbSection sections[NUM_SECTIONS_MAX];
char stringBuf[STRING_BUF_LEN];
char *stringBufPtr;

rgbLONG_t
	rev,
	numSymbols,
	numSections,
	numNodes;

// File reading routines ---------------------------------------------------------

/** 
 * Reads a 32bit little-endian signed integer from a file
 */
rgbLONG_t ReadLong(FILE *f)
{
	uint8_t bytes[4];
	fread(bytes, 4, 1, f);
	uint32_t u32 =
		(uint32_t) bytes[0] |
		((uint32_t) bytes[1]<<8) |
		((uint32_t) bytes[2]<<16) |
		((uint32_t) bytes[3] << 24);
	int32_t i32;
	if(u32 > (uint32_t) INT32_MAX){
		return -(int32_t) ((UINT32_MAX - u32) + 1);
	}
	return u32;
}

const char *error_ReadStr;

/** 
 * Reads a null terminated string from a file,
 * if null is returned, error_ReadStr is set
 */
char *ReadStr(FILE *f)
{
	char *string = stringBufPtr;
	int ch;
	
	while(1){
		ch = fgetc(f);
		*stringBufPtr = ch;
		if(!ch) break;
		if(ch == EOF){
			error_ReadStr = "End-of-file before string terminator";
			return 0;
		}
		stringBufPtr++;
		
		if(stringBufPtr - string > STRING_LEN_MAX-1){
			error_ReadStr = "Exceeded max string length";
			return 0;
		}
		if(stringBufPtr - stringBuf > STRING_BUF_LEN-1){
			error_ReadStr = "Exhausted string memory";
			return 0;
		}
	}
	*stringBufPtr++ = 0;
	return string;
}

/** 
 * Skips n bytes in a file
 */
int SkipFileBytes(FILE *f, rgbLONG_t n)
{
	for(rgbLONG_t j = 0; j < n; j++){
		if(fgetc(f) == EOF) return 1;
	}
	return 0;
}

// Misc verification checks ------------------------------------------------------

/** 
 * Checks if a string is a valid identifier (no whitespace or non-print characters)
 */
int CheckIdentifier(const char *name)
{
	do{
		if(!isprint(*name)) return 1;
		if(isspace(*name)) return 1;
	}while(*++name);
	return 0;
}

/** 
 * Checks if a string is a valid filename for a tags file (no tabs or non-print characters)
 */
int CheckFilename(const char *name)
{
	do{
		if(!isprint(*name)) return 1;
		if(*name == '\t') return 1;
	}while(*++name);
	return 0;
}

// Main obj file reader routine --------------------------------------------------

/** 
 * Main OBJ reader, returns null on success or error description string on failure
 */
const char *ReadObj(const char *fn)
{
	error_ReadStr = 0;
	stringBufPtr = stringBuf;
	
	const char *error = 0;
	FILE *obj = fopen(fn, "rb");
	
	if(!obj){
		error = "Unable to open file";
		goto end;
	}
	
	// Header -----------------------------
	
	char magic[4];
	fread(magic, sizeof(magic), 1, obj);
	if(memcmp(magic, "RGB9", 4)){
		error = "Invalid magic number";
		goto end;
	}
	
	rev = ReadLong(obj);
	numSymbols = ReadLong(obj);
	numSections = ReadLong(obj);
	
	if(rev != 9){
		error = "Invalid revision number";
		goto end;
	}
	
	#if 0
	printf("%d rev %d #syms %d #sections\n", rev, numSymbols, numSections);
	#endif
	
	// Source file info -------------------
	
	numNodes = ReadLong(obj);
	
	if(numNodes < 0){
		error = "Invalid number of nodes";
		goto end;
	}
	if(numNodes > NUM_NODES_MAX){
		error = "Number of nodes too large";
		goto end;
	}
	
	memset(nodes, 0, numNodes * sizeof(*nodes));
		
	#if 0
	printf("%d #nodes\n", numNodes);
	#endif
	
	for(rgbLONG_t id = numNodes - 1; id >= 0; id--){
		struct rgbNode
			*node = nodes + id;
		
		node->parentID = ReadLong(obj);
		node->parentLineNo = ReadLong(obj);
		node->type = fgetc(obj);
		
		if(node->type < 0 || node->type > RGBNODE_TYPE_MAX){
			error = "Invalid node type";
			goto end;
		}
		
		if(node->type != RGBNODE_TYPE_REPT){
			node->name = ReadStr(obj);
			if(!node->name){
				error = "Error reading node name";
				goto end;
			}
			
			if(node->type == RGBNODE_TYPE_FILE && CheckFilename(node->name)){
				error = "Invalid filename";
			}
			
			#if 0
			printf("%d parentID \"%s\" name\n", node->parentID, node->name);
			#endif
		}
		else{
			node->depth = ReadLong(obj);
			for(rgbLONG_t j = 0; j < node->depth; j++){
				rgbLONG_t
					iter = ReadLong(obj);
			}
		}
	}
	
	// Symbols ----------------------------
	
	if(numSymbols < 0){
		error = "Invalid number of symbols";
		goto end;
	}
	if(numSymbols > NUM_SYMBOLS_MAX){
		error = "Number of symbols too large";
		goto end;
	}
	
	memset(symbols, 0, numSymbols * sizeof(*symbols));
	
	for(rgbLONG_t i = 0; i < numSymbols; i++){
		struct rgbSymbol
			*symbol = symbols + i;
		symbol->name = ReadStr(obj);
		if(!symbol->name){
			error = "Error reading symbol name";
			goto end;
		}
		symbol->type = fgetc(obj);
		
		if(symbol->type < 0 || symbol->type > RGBSYMBOL_TYPE_MAX){
			error = "Invalid symbol type";
			goto end;
		}
		
		if(symbol->type != RGBSYMBOL_TYPE_IMPORT){
			symbol->nodeID = ReadLong(obj);
			symbol->lineNo = ReadLong(obj);
			symbol->sectionId = ReadLong(obj);
			symbol->value = ReadLong(obj);
			#if 0
			if(symbol->name[0] && symbol->nodeID == 0) printf("%03d %64s %09d %09d\n", i, symbol->name, symbol->lineNo, symbol->nodeID);
			if(symbol->name[0] && symbol->nodeID != 0) printf("%03d %64s %09d %09d (%s)\n", i, symbol->name, symbol->lineNo, symbol->nodeID, nodes[symbol->nodeID].name);
			#endif
			if(symbol->nodeID < 0 || symbol->nodeID >= numNodes){
				error = "Invalid symbol node ID";
				goto end;
			}
			if(symbol->lineNo < 0){
				error = "Invalid symbol line number";
				goto end;
			}
			if(CheckIdentifier(symbol->name)){
				error = "Invalid symbol name";
				goto end;
			}
			if(symbol->sectionId < -1 || symbol->sectionId >= numSections){
				error = "Invalid symbol section ID";
				goto end;
			}
		}
	}
	
	// Sections ---------------------------
	
	if(numSections < 0){
		error = "Invalid number of sections";
		goto end;
	}
	if(numSections > NUM_SECTIONS_MAX){
		error = "Number of sections too large";
		goto end;
	}
	
	memset(sections, 0, numSections * sizeof(*sections));
	
	for(rgbLONG_t i = 0; i < numSections; i++){
		struct rgbSection
			*section = sections + i;
		section->name = ReadStr(obj);
		section->size = ReadLong(obj);
		section->type = fgetc(obj);
		
		if(section->type < 0 || section->type > RGBSECTION_TYPE_MAX){
			error = "Invalid section type";
			goto end;
		}
		
		section->address = ReadLong(obj);
		section->bank = ReadLong(obj);
		section->alignment = fgetc(obj);
		section->alignOfs = ReadLong(obj);
		if(section->type == RGBSECTION_TYPE_ROM0 || section->type == RGBSECTION_TYPE_ROMX){
			if(SkipFileBytes(obj, section->size)){
					error = "End-of-file in section data";
					goto end;
			}
			section->numPatches = ReadLong(obj);
			for(int j = 0; j < section->numPatches; j++){
				ReadLong(obj); //NodeId
				ReadLong(obj); //LineNo
				ReadLong(obj); //Offset
				ReadLong(obj); //PCSectionID
				ReadLong(obj); //PCOffset
				fgetc(obj);    //Type
				rgbLONG_t
					rpnSize = ReadLong(obj);
				if(SkipFileBytes(obj, rpnSize)){
					error = "End-of-file in patch data";
					goto end;
				}
			}
		}
	}
	
	// Assertions ------------------------
	// [...]
	
	if(ferror(obj)){
		error = "File reading error";
	}
	
	end:
	if(obj) fclose(obj);
	return error;
}

// Ctag handling routines --------------------------------------------------------

#define CTAG_LEN_MAX 4096

/** 
 * Ctag structure
 * Implemented as doubly-linked list
 */
struct Ctag
{
	int tagLen;                /*!< Length of str */
	int nameLen;               /*!< Length of only the tagname part of str */
	struct Ctag *prev, *next;  /*!< Linked-list pointers */
	char str[];                /*!< Line that goes into tags file, Flexible Array Member */
};

/** 
 * DJB2 string hash
 */
uint32_t HashDJB2(const char *str)
{
	uint32_t hash = 5381;
	int c;
	
	while((c = *str++)) hash = ((hash << 5) + hash) + c;
	
	return hash;
}

/** 
 * Hash table to quickly check for identical/duplicate tags
 */
struct Ctag *ctags[256] = {};

int numCtags = 0, numCtagsUnique = 0;

/** 
 * Adds a tags line to ctags hashtable, if non-duplicate
 */
void AddCtag(const char *str, int tagLen, int nameLen)
{
	numCtags++;
	
	uint32_t hash = HashDJB2(str);
	hash &= 0xFFu;
	
	struct Ctag *parent = ctags[hash];
	if(parent){
		while(1){
			if(parent->tagLen == tagLen && !strncmp(parent->str, str, tagLen)) return;
			if(!parent->next) break;
			parent = parent->next;
		}
	}
	
	numCtagsUnique++;
	
	struct Ctag *ctag = calloc(1, sizeof(*ctag)+tagLen+1);
	ctag->tagLen = tagLen;
	ctag->nameLen = nameLen;
	strncpy(ctag->str, str, tagLen+1);
	
	ctag->prev = parent;
	if(parent) parent->next = ctag;
	else ctags[hash] = ctag;
}

/** 
 * Transforms symbols into tag lines in ctags table
 * Returns non-zero on error
 */
int CreateCtags(void)
{
	for(rgbLONG_t i = 0; i < numSymbols; i++){
		struct rgbSymbol
			*symbol = symbols + i;
		
		//Skip nameless symbols (maybe they don't even exist?)
		if(!symbol->name[0]) continue;
		
		//Skip symbols from other files
		if(symbol->type == RGBSYMBOL_TYPE_IMPORT) continue;
		
		struct rgbNode
			*node = nodes + symbol->nodeID;
		
		//Skips symbols created within macros
		if(node->type != RGBNODE_TYPE_FILE) continue;
		
		const char
			*fileName = (node->name),
			*name = symbol->name,
			*type = "";
		const rgbLONG_t
			lineNo = symbol->lineNo;
		
		//Negative SectionID means a macro constant
		if(symbol->sectionId < 0){
			type = "d";
		}
		else{
			//Guess symbol type from section type
			//ROM = function,
			//RAM = variable
			struct rgbSection
				*section = sections + symbol->sectionId;
			switch(section->type){
				case RGBSECTION_TYPE_WRAM0 :
				case RGBSECTION_TYPE_VRAM  :
				case RGBSECTION_TYPE_WRAMX :
				case RGBSECTION_TYPE_SRAM  :
				case RGBSECTION_TYPE_HRAM  :
				case RGBSECTION_TYPE_OAM   :
					type = "v";
					break;
				
				case RGBSECTION_TYPE_ROMX  :
				case RGBSECTION_TYPE_ROM0  :
					type = "f";
					break;
				default:
					break;
			}
		}
		
		//Build tags line
		char tagStr[CTAG_LEN_MAX];
		int n = snprintf(tagStr, CTAG_LEN_MAX, "%s\t%s\t%d;\"\t%s", name, fileName, lineNo, type);
		if(n+1 >= CTAG_LEN_MAX) return 1;
		if(n < 0) return 1;
		
		AddCtag(tagStr, n, strlen(name));
	}
	
	return 0;
}

/**
 * Read a line from a tags file
 */
int ReadTagLine(FILE *f, char *lin)
{
	int len;
	for(len = 0; len < CTAG_LEN_MAX; len++, lin++){
		int ch = fgetc(f);
		if(ch == EOF){
			if(len) return -1;
			return 0;
		}
		if(ch == '\n') break;
		*lin = ch;
	}
	if(len >= CTAG_LEN_MAX){
		return -1;
	}
	
	*lin = 0;
	return len;
}

/**
 * Append to ctags from a tags file
 * Returns null or success, or error description string on failure
 */
const char *AppendCtags(const char *fileName)
{
	FILE *file = fopen(fileName, "r");
	const char *error = 0;
	if(!file){
		error = "Cant open tags file for reading";
		goto end;
	}
	
	while(1){
		char tagStr[CTAG_LEN_MAX];
		const int tagLen = ReadTagLine(file, tagStr);
		if(!tagLen) break;
		if(tagLen < 0){
			error = "Unexpected end-of-file while reading tags";
			goto end;
		}
		int nameLen = 0, fileLen, addrLen;
		const char *ptr = tagStr;
		for(ptr = tagStr, nameLen = 0; ptr < tagStr + tagLen; nameLen++, ptr++){
			if(*ptr == '\t'){
				ptr++;
				break;
			}
			if(!isprint(*ptr)){
				#if 0
				printf("bad line with non-print char '%c' (%d): \"%s\"", *ptr, *ptr, tagStr);
				#endif
				error = "Read invalid tag line";
				goto end;
			}
		}
		for(fileLen = 0; ptr < tagStr + tagLen; fileLen++, ptr++){
			if(*ptr == '\t'){
				ptr++;
				break;
			}
		}
		for(addrLen = 0; ptr < tagStr + tagLen; addrLen++, ptr++){
			if(*ptr == '\t'){
				ptr++;
				break;
			}
		}
		if(!nameLen || !fileLen || !addrLen){
			#if 0
			printf("bad line with namelen %d filelen %d addrlen %d: \"%s\"", nameLen, fileLen, addrLen, tagStr);
			#endif
			error = "Read invalid tag line";
			goto end;
		}
		
		AddCtag(tagStr, tagLen, nameLen);
	}
	
	if(ferror(file)) error = "I/O error reading tags file";
	
	end:
	if(file) fclose(file);
	return error;
}

// Merge-sort for Ctag double linked lists ---------------------------------------

/** 
 * Lexicographical tag line sorter
 */
int CmpCtag(struct Ctag *a, struct Ctag *b)
{
	const int aShortest = a->nameLen < b->nameLen;
	const int nameLen = aShortest ? a->nameLen : b->nameLen;
	const int cmp = strncmp(a->str, b->str, nameLen);
	int res;
	if(cmp) res = cmp;
	else res = aShortest ? -1 : 1;
	
	#if 0
	printf("%.*s %s %.*s\n",
		a->nameLen, a->str,
		(res > 0) ? ">" : "<",
		b->nameLen, b->str
	);
	#endif
	
	return res;
}

/** 
 * Merge two linked lists
 */
struct Ctag *MergeCtags(struct Ctag *first, struct Ctag *second)
{
	if(!first) return second;
	if(!second) return first;
	
	if(CmpCtag(first, second) < 0){
		first->next = MergeCtags(first->next,second);
		first->next->prev = first;
		first->prev = NULL;
		return first;
	}
	else{
		second->next = MergeCtags(first,second->next);
		second->next->prev = second;
		second->prev = NULL;
		return second;
	}
}

/** 
 * Splits a list into two halves
 */
struct Ctag *SplitCtags(struct Ctag *head)
{
	struct Ctag *fast = head,*slow = head;
	while(fast->next && fast->next->next){
		fast = fast->next->next;
		slow = slow->next;
	}
	struct Ctag *temp = slow->next;
	slow->next = NULL;
	return temp;
}
 
/** 
 * Sorts a linked list of tags
 */
struct Ctag *SortCtags(struct Ctag *head)
{
	if(!head || !head->next) return head;
	struct Ctag *second = SplitCtags(head);
	
	head = SortCtags(head);
	second = SortCtags(second);
	
	return MergeCtags(head,second);
}

// Main --------------------------------------------------------------------------

int main(int argc, char **argv)
{
	int argIdx;
	const char *tagsFileName = "tags";
	int append = 0;
	
	if(argc < 2){
		usage:
		puts(
			"kdrnic's ctags for RGBDS\n"
			"Usage:\n"
			"rgbtags [options] [object files]\n"
			"\n"
			"Options:\n"
			"-f <file>             Specify an output file (default \"tags\")\n"
			"-a                    tags generated from the specified files should be appended\n"
			"                      to those already present in the tag file\n"
		);
		return 0;
	}
	
	//Parse options
	for(argIdx = 1; argIdx < argc; argIdx++){
		const char *option = argv[argIdx];
		if(option[0] != '-') break;
		
		if(!strcmp(option, "-f")){
			argIdx++;
			if(argIdx >= argc) goto usage;
			tagsFileName = argv[argIdx];
		}
		else if(!strcmp(option, "-a")){
			append = 1;
		}
	}
	
	if(append){
		const char *error = AppendCtags(tagsFileName);
		if(error){
			fprintf(stderr, "Error parsing tags file (append mode): %s", error);
			return 1;
		}
	}
	
	//Parse object files
	for(; argIdx < argc; argIdx++){
		const char *fileName = argv[argIdx];
		const char *error;
		
		error = ReadObj(fileName);
		if(error){
			fprintf(stderr, "Error reading object file %s: %s", fileName, error);
			if(error_ReadStr) fprintf(stderr, " (%s)\n", error_ReadStr);
			else fprintf(stderr, "\n");
			return 1;
		}
		
		if(CreateCtags()){
			fprintf(stderr, "Error creating ctags for object file %s", fileName);
			return 1;
		}
	}
	
	//Merge ctags hash table into single list
	struct Ctag *first = 0, *curr = 0;
	for(int i = 0; i < 256; i++){
		first = MergeCtags(first, ctags[i]);
	}
	
	//Open tags file for writing
	FILE *out = fopen(tagsFileName, "w");
	if(!out){
		fprintf(stderr, "Cant open tags file for writing");
		return 1;
	}
	
	//Sort tags (necessary because tags files are binary searched)
	curr = SortCtags(first);
	//Write to tags file, finally
	while(curr){
		fputs(curr->str, out);
		fputc('\n', out);
		curr = curr->next;
		if(curr) free(curr->prev);
	}
	
	fclose(out);
	
	#if 0
	printf("%d %d %d %d\n", numSymbols, numCtags, numCtags2, numCtagsUnique);
	#endif
	
	return 0;
}
