KDRNIC's DOOM LEVEL LOADER

Run GAME.EXE from Windows, it is a 32bit executable.
Run GAMEDOS.EXE from DOSBox/MS-DOS. It requires at least 16MB RAM, maybe more.
Compiling the PVS takes long in the DOS version, looking like it is frozen.

Included is DOOM1.WAD, the original shareware version of DOOM.

License
The license is unclear.

Command line arguments
GAMEDOS.EXE [WADFILE] [MAP] [-nopvs] [-exportobj] [-ss]
WADFILE		such as DOOM1.WAD
MAP			such as E1M1 - case sensitive
-nopvs		do not build PVS - takes less time to enter 3D view but renders slower
-exportobj	exports .OBJ, .MTL files and textures
-ss			shows sectors as debug information

Cfg file options
screenw/screenh		Window size. For proper aspect ratio must be 4:3
renderw/renderh		Framebuffer size, scaled to fit screen. For proper aspect ratio must be 8:5
texres				Scale textures to this resolution, Must be power of 2
waddir/waddir2		Directoris with WAD files
midi_card			May be set to DIGI for wavetable MIDI synthesizer
patches				Allegro wavetable patches file

Orthographic topdown view controls
Controls:
L mouse click - spawn at cursor position
R mouse click - spawn at cursor position, way up high, looking down, similarly to ortho view
M mouse click - spawn at singleplayer spawn
Mouse wheel   - zoom in/out
Dir keys      - move around
Esc           - quit

First person 3D view controls
Left/right    - turn
W/S           - move freely
Up/dow        - move with floor collision
A/D           - strafe
Mouse wheel   - change FOV
Dir keys      - move around
Esc           - quit
Shift         - run
N             - enter node number with +- 0123456789 backspace
+-            - change node number
0             - select child node 0
1             - select child node 1
P             - select parent node
