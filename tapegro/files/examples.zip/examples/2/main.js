frame = 0;
GAME_STATE_WAIT = 0;
GAME_STATE_GAMEOVER = 1;
GAME_STATE_PLAY = 2;
gameState = 0;
oldButtons = [0, 0, 0, 0];
debug = false;

ship = {
	x: screen.w / 2,
	y: screen.h / 2,
	dx: 0,
	dy: 0,
	angle: 0,
	alive: false,
	radius: 4,
	accel: 0.1,
	turnSpeed: 0.1,
	friction: 0.005
};

laserSound = LoadSample("laser.wav");
teleSound = LoadSample("tele.wav");
explosionSounds = [LoadSample("expl1.wav"), LoadSample("expl2.wav"), LoadSample("expl3.wav")];
laserBitmap = LoadBitmap("laser.pcx");
bulletSpritesheet = CreateSpriteSheet(laserBitmap, 25, 25);
shipSprite = CreateSpriteSheet(LoadBitmap("ship.pcx"), 25, 25);
asteroidSpritesheet = CreateSpriteSheet(LoadBitmap("asteroid.pcx"), 51, 54);
SetPalette(LastBitmapPalette());

bulletAnimSpeed = 3;
bulletLifetime = 45;
bulletSpeed = 4;
bulletRadius = 2;

asteroidScale = [1, 0.6, 0.35, 0.225];
asteroidAnimLength = asteroidSpritesheet.numberOfFrames / 2;
asteroidAnimSpeed = [4.5, 4, 3.5, 3];
asteroidSpeed = [1, 1.5, 1.75, 1.875];
asteroidRadius = [27, 27/2, 27/4, 27/8];

maxAsteroids = 10 * 8;
maxBullets = bulletLifetime;
asteroids = [];
bullets = [];
asteroidSprites = new Int32Array(maxAsteroids * 6);
for(var i = 0; i < maxAsteroids * 6; i += 6) asteroidSprites[i + 2] = -1;
bulletSprites = new Int32Array(maxBullets * 4);
for(var i = 0; i < maxBullets * 4; i += 4) bulletSprites[i + 2] = -1;
bulletIndex = 0;
asteroidIndex = 0;

function PlayExplosion(){
	PlaySample(explosionSounds[Math.floor(explosionSounds.length * Math.random())], 175, 128, 900 + Math.random() * 100, 0);
}

function Wrap(obj){
	if(obj.x < 0 - obj.radius) obj.x = screen.w + obj.radius;
	if(obj.y < 0 - obj.radius) obj.y = screen.h + obj.radius;
	if(obj.x > screen.w + obj.radius) obj.x = 0 - obj.radius;
	if(obj.y > screen.h + obj.radius) obj.y = 0 - obj.radius;
}

function Move(obj){
	obj.x += obj.dx;
	obj.y += obj.dy;
	Wrap(obj);
}

function Collision(a, b){
	if((a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y) < (a.radius + b.radius) * (a.radius + b.radius)) return true;
	return false;
}

function CreateAsteroid(g, x, y){
	var moveAngle = Math.random() * 999;
	var spd = 0.75 + Math.random() * 0.25;
	var a = {
		generation: g,
		x: x,
		y: y,
		dx: Math.cos(moveAngle) * asteroidSpeed[g] * spd,
		dy: Math.sin(moveAngle) * asteroidSpeed[g] * spd,
		angle: FloatToFix(Math.random() * 256),
		scale: FloatToFix(asteroidScale[g]),
		fScale: asteroidScale[g],
		flips: (Math.random() > 0.5 ? FLIP_V : 0) | (Math.random() > 0.5 ? FLIP_H : 0),
		time: Math.random() * 999,
		animSpeed: asteroidAnimSpeed[g],
		type: Math.random() > 0.5 ? 1 : 0,
		radius: asteroidRadius[g],
		spr: ((asteroidIndex++) % maxAsteroids) * 6
	};
	asteroidSprites[a.spr + 3] = a.angle;
	asteroidSprites[a.spr + 4] = a.scale;
	asteroidSprites[a.spr + 5] = a.flips;
	return a;
}

function DestroyAsteroid(i, a){
	asteroidSprites[a.spr + 2] = -1;
	PlayExplosion();
	if(a.generation < 3){
		asteroids[i] = CreateAsteroid(a.generation + 1, a.x, a.y);
		asteroids.push(CreateAsteroid(a.generation + 1, a.x, a.y));
	}
	else{
		asteroids[i] = asteroids[asteroids.length - 1];
		asteroids[asteroids.length - 1] = a;
		asteroids.pop();
	}
}

function SpawnAsteroid(){
	asteroids.push(CreateAsteroid(0, Math.random() * screen.w, Math.random() * screen.h));
}

function UpdateAsteroids(){
	var numAsteroids = asteroids.length;
	for(var i = 0; i < numAsteroids; i++){
		var a = asteroids[i];
		
		a.time++;
		
		Move(a);
		
		if(Collision(a, ship)){
			DestroyShip();
		}
		
		asteroidSprites[a.spr + 0] = a.x - asteroidSpritesheet.width * a.fScale * 0.5;
		asteroidSprites[a.spr + 1] = a.y - asteroidSpritesheet.height * a.fScale * 0.5;
		asteroidSprites[a.spr + 2] = (((a.time / a.animSpeed) % asteroidAnimLength) | 0) + asteroidAnimLength * a.type;
	}
}

function DestroyShip(){
	if(!ship.alive) return;
	PlayExplosion();
	ship.alive = false;
}

function SpawnShip(){
	ship.alive = true;
	ship.x = screen.w / 2;
	ship.y = screen.h / 2;
	ship.dx = ship.dy = 0;
}

function UpdateShip(){
	if(!ship.alive){
		if(buttons[0] & BUTTON_START) SpawnShip();
		ship.frame = 1;
		return;
	}
	
	if(buttons[0] & (~oldButtons[0]) & BUTTON_A){
		SpawnBullet();
	}
	if(buttons[0] & (~oldButtons[0]) & BUTTON_B){
		PlaySample(teleSound, 160, 128, 1000, 0);
		ship.x = Math.random() * screen.w;
		ship.y = Math.random() * screen.h;
	}
	
	ship.frame = 0;
	ship.dx -= Math.cos(ship.angle) * dpad[0].y * ship.accel;
	ship.dy -= Math.sin(ship.angle) * dpad[0].y * ship.accel;
	ship.dx -= ship.dx * ship.friction;
	ship.dy -= ship.dy * ship.friction;
	ship.angle += dpad[0].x * ship.turnSpeed;
	Move(ship);
}

function SpawnBullet(){
	PlaySample(laserSound, 150, 128, 990 + Math.random() * 20, 0);
	var b;
	bullets.push(b = {
		x: ship.x,
		y: ship.y,
		time: 0,
		dx: Math.cos(ship.angle) * bulletSpeed,
		dy: Math.sin(ship.angle) * bulletSpeed,
		angle: FloatToFix(256 * ship.angle / (Math.PI * 2)),
		radius: bulletRadius,
		spr: ((bulletIndex++) % maxBullets) * 4
	});
	bulletSprites[b.spr + 3] = b.angle;
}

function UpdateBullets(){
	for(var i = 0; i < bullets.length; i++){
		var b = bullets[i];
		
		Move(b);
		
		b.time++;
		if(b.time > bulletLifetime) b.dead = true;
		
		for(var j = 0; j < asteroids.length; j++){
			if(Collision(b, asteroids[j])){
				DestroyAsteroid(j, asteroids[j]);
				b.dead = true;
			}
		}
		
		bulletSprites[b.spr + 0] = b.x - bulletSpritesheet.width * 0.5;
		bulletSprites[b.spr + 1] = b.y - bulletSpritesheet.height * 0.5;
		bulletSprites[b.spr + 2] = (b.time / bulletAnimSpeed) %  bulletSpritesheet.numberOfFrames;
		
		if(b.dead){
			bulletSprites[b.spr + 2] = -1;
			bullets[i] = bullets[bullets.length - 1];
			bullets.pop();
		}
	}
	
}

function DrawCircle(obj){
	Circle(screen, obj.x, obj.y, obj.radius, 1 + Math.random() * 254);
}

function Loop(){
	if(asteroids.length == 0){
		SpawnAsteroid();
		SpawnAsteroid();
		SpawnAsteroid();
	}
	UpdateShip();
	UpdateBullets();
	UpdateAsteroids();
	
	ClearToColor(screen, 1);
	DrawSpriteBatch(screen, asteroidSpritesheet, SPRITE_ROTATE | SPRITE_SCALE | SPRITE_FLIP, asteroidSprites);
	DrawSpriteBatch(screen, bulletSpritesheet, SPRITE_ROTATE, bulletSprites);
	DrawTransformSprite(screen, shipSprite, SPRITE_ROTATE, ship.x - 12.5, ship.y - 12.5, ship.frame, FloatToFix(256 * ship.angle / (Math.PI * 2)));
	
	if(debug){
		var stuff = [ship].concat(bullets).concat(asteroids);
		stuff.forEach(DrawCircle);
	}
	
	oldButtons = buttons.slice();
}