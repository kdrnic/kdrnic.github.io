
bg = LoadBitmap("outrun.pcx");
bgTime = FileTime("outrun.pcx");
SetPalette(pal = LastBitmapPalette());
lightMap = CreateLightTable(pal, 0, 0, 0);
SetColorMap(lightMap);
bgx = 0;
x = screen.w / 2;
y = screen.h / 2;
tx = 0;
ty = 0;
light = 128;
r = 50;
spot = CreateBitmap(r, r);
for(var i = 0; i < r; i++) CircleFill(spot, spot.w / 2, spot.h / 2, i, light / i);
SetPrimitiveDrawingMode(1);
Cout(JSON.stringify(ListFiles("*.c")));
frame = 0;
function Loop(){
	frame++;
	if(!(frame % 60))
	{
		if(FileTime("outrun.pcx") > bgTime)
		{
			bg = LoadBitmap("outrun.pcx");
		}
	}
	x += dpad[0].x;
	y += dpad[0].y;
	DrawBitmap(screen, bg, bgx, 0);
	CircleFill(screen, x, y, r, light);
	TextOut(screen, "FPS: " + fps, tx, ty, 1);
	if(Key(KEY_ESC)) Quit();
}
